
__version__ = "0.1.0"

__version__ = "0.1.0"

# Path: src/fastq_handler/__main__.py
# Compare this snippet from src/fastq_handler/__main__.py:
# import argparse
#
# from fastq_handler.fastq_handler import PreMain
